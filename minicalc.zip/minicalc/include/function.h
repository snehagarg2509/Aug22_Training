int sum(int, int);

int sub(int, int);
