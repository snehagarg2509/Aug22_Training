#include<stdio.h>
#include<function.h>

int main()
{

	int x = 4, y = 3;
	printf("Suim = %d\n", sum(x,y));
	printf("Difference = %d\n", sub(x,y));
	return 0;
}
