int sum(int x, int y)
{
	return x + y;
}

int sub(int a, int b)
{
	return a-b;
}
